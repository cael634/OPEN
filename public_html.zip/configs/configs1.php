<?php
@session_start();
@extract($_REQUEST);

$host_mysql = "localhost";
$user_mysql = "root";
$pass_mysql = "";
$db_mysql = "tren"; 
$divisa = " COP";
?>