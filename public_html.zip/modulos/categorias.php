        <div class="site__body" style="    min-height: 500px;
}">
            <div class="page-header">
                <div class="page-header__container container">
                    <div class="page-header__breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="?p=productos">Home</a>
                                    <svg class="breadcrumb-arrow" width="6px" height="9px">
                                        <use xlink:href="images/sprite.svg#arrow-rounded-right-6x9"></use>
                                    </svg>
                                </li>
                               
                                <li class="breadcrumb-item active" aria-current="page">Todas las categorias</li>
                            </ol>
                        </nav>
                  
                </div>
            </div>
             <div class="block block--highlighted block-categories block-categories--layout--compact" style="padding: 0px">
                <div class="container">
                    <div class="block-header">
                        <h3 class="block-header__title">Categorias</h3>
                        <div class="block-header__divider"></div>
                    </div>
                    <div class="block-categories__list">
                       
                        <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=1"><img src="categorias/spices.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=1">Despensa</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Lathes</a></li>
                                        <li><a href="">Milling Machines</a></li>
                                        <li><a href="">Grinding Machines</a></li>
                                        <li><a href="">CNC Machines</a></li>
                                        <li><a href="">Sharpening Machines</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=2"><img src="categorias/sugar.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=2">Abarrotes</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Generators</a></li>
                                        <li><a href="">Compressors</a></li>
                                        <li><a href="">Winches</a></li>
                                        <li><a href="">Plasma Cutting</a></li>
                                        <li><a href="">Electric Motors</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=3"><img src="categorias/bocadillo.png"alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=3">Pasabocas salados</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Tape Measure</a></li>
                                        <li><a href="">Theodolites</a></li>
                                        <li><a href="">Thermal Imagers</a></li>
                                        <li><a href="">Calipers</a></li>
                                        <li><a href="">Levels</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=6"><img src="categorias/golosinas.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=6">Golosinas</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Winter Workwear</a></li>
                                        <li><a href="">Summer Workwear</a></li>
                                        <li><a href="">Helmets</a></li>
                                        <li><a href="">Belts and Bags</a></li>
                                        <li><a href="">Work Shoes</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                         <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=7"><img src="categorias/bebida-sin-alcohol.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=7">Bebidas</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Winter Workwear</a></li>
                                        <li><a href="">Summer Workwear</a></li>
                                        <li><a href="">Helmets</a></li>
                                        <li><a href="">Belts and Bags</a></li>
                                        <li><a href="">Work Shoes</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                         <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=8"><img src="categorias/carniceria.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=8">Carnes</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Winter Workwear</a></li>
                                        <li><a href="">Summer Workwear</a></li>
                                        <li><a href="">Helmets</a></li>
                                        <li><a href="">Belts and Bags</a></li>
                                        <li><a href="">Work Shoes</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                         <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=9"><img src="categorias/cleaning (1).png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=9">Aseo hogar</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Winter Workwear</a></li>
                                        <li><a href="">Summer Workwear</a></li>
                                        <li><a href="">Helmets</a></li>
                                        <li><a href="">Belts and Bags</a></li>
                                        <li><a href="">Work Shoes</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                         <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=10"><img src="categorias/soap.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=10">Aseo personal</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Winter Workwear</a></li>
                                        <li><a href="">Summer Workwear</a></li>
                                        <li><a href="">Helmets</a></li>
                                        <li><a href="">Belts and Bags</a></li>
                                        <li><a href="">Work Shoes</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                         <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=11"><img src="categorias/recien-nacido.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=11">Productos para bebes</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Winter Workwear</a></li>
                                        <li><a href="">Summer Workwear</a></li>
                                        <li><a href="">Helmets</a></li>
                                        <li><a href="">Belts and Bags</a></li>
                                        <li><a href="">Work Shoes</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                         <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=12"><img src="categorias/comida.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=6">Productos para mascotas</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Winter Workwear</a></li>
                                        <li><a href="">Summer Workwear</a></li>
                                        <li><a href="">Helmets</a></li>
                                        <li><a href="">Belts and Bags</a></li>
                                        <li><a href="">Work Shoes</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                         <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=4"><img src="categorias/vegetables.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=4">Verduras frescas</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Screwdrivers</a></li>
                                        <li><a href="">Milling Cutters</a></li>
                                        <li><a href="">Sanding Machines</a></li>
                                        <li><a href="">Wrenches</a></li>
                                        <li><a href="">Drills</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="block-categories__item category-card category-card--layout--compact">
                            <div class="category-card__body">
                                <div class="category-card__image">
                                    <a href="?p=categoriasver&id=5"><img src="categorias/fruta.png" alt=""></a>
                                </div>
                                <div class="category-card__content">
                                    <div class="category-card__name">
                                        <a href="?p=categoriasver&id=5">Frutas frescas</a>
                                    </div>
                                    <ul class="category-card__links">
                                        <li><a href="">Screwdrivers</a></li>
                                        <li><a href="">Hammers</a></li>
                                        <li><a href="">Spanners</a></li>
                                        <li><a href="">Handsaws</a></li>
                                        <li><a href="">Paint Tools</a></li>
                                    </ul>
                                    <div class="category-card__all">
                                        <a href="">Show All</a>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                           
                        </div>
                    </div>
                </div>
                <br>
                <footer class="site__footer">
            <div class="site-footer">
                <div class="container">
                    <div class="site-footer__widgets">
                        <div class="row">
                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="site-footer__widget footer-contacts">
                                    <h5 class="footer-contacts__title">Contactos</h5>
                                    
                                    <ul class="footer-contacts__contacts">
                                        <li><i class="footer-contacts__icon fas fa-globe-americas"></i> open.com.se</li>
                                        <li><i class="footer-contacts__icon far fa-envelope"></i> servicioalcliente@open.com.se</li>
                                     
                                        <li><i class="footer-contacts__icon far fa-clock"></i>Horario de atención al cliente:<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9:00am - 9:00pm  Lunes a sabado</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-6 col-md-3 col-lg-2">
                                <div class="site-footer__widget footer-links">
                                    <h5 class="footer-links__title">Información</h5>
                                    <ul class="footer-links__list">
                                        <li class="footer-links__item"><a href="" class="footer-links__link">Acerca de nosotros</a></li>
                                        <li class="footer-links__item"><a href="" class="footer-links__link">Informacion de entrega</a></li>
                                        <li class="footer-links__item"><a href="" class="footer-links__link">Politica de privacidad</a></li>
 
                                      
                                        
                                    </ul>
                                </div>
                            </div>
                            
                           <style type="text/css">
                               .site-footer__widgets {
    padding: 25px 0 17px;
}
.footer-links li {
    display: block;
    width: 300px !important;
}
                           </style> 
                        </div>
                    </div>
                    <div class="site-footer__bottom">
                        <div class="site-footer__copyright">
                            <!-- copyright -->
                           Desarrollado por HTML - Diseño por <a href="https://themeforest.net/user/kos9" target="_blank">Kos</a>
                            <!-- copyright / end -->
                        </div>
                        
                    </div>
                </div>
                <div class="totop">
                    <div class="totop__body">
                        <div class="totop__start"></div>
                        <div class="totop__container container"></div>
                        <div class="totop__end">
                            <button type="button" class="totop__button">
                                <svg width="13px" height="8px">
                                    <use xlink:href="images/sprite.svg#arrow-rounded-up-13x8"></use>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- site__footer / end -->
    </div>
    <!-- site / end -->
    <!-- quickview-modal -->
   
<style type="text/css">
    .site-footer {
    background-color: #26272b;
    padding: 0px 0 20px !important;
    font-size: 15px;
    line-height: 24px;
    color: #737373;
}
</style>
        