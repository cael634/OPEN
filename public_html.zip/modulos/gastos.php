<!doctype html>
<html lang="en">
  <head>
    <style type="text/css">
  
 .cuerpo {
    background: #fff;
    padding: 0px!important;
    min-height: 500px;
    text-align: inherit!important;
} 
div.dataTables_wrapper div.dataTables_length label {
    font-weight: normal;
    text-align: left;
    display: none;
    white-space: nowrap;
}

h1 {
    font-size: 36px!important;
    font-weight: 700 !important;
    font-family: 'Raleway', sans-serif !important;
   
}

div.dataTables_wrapper div.dataTables_length, div.dataTables_wrapper div.dataTables_filter, div.dataTables_wrapper div.dataTables_info, div.dataTables_wrapper div.dataTables_paginate {
    text-align: inherit !important;
}
    </style>

<?php
if(isset($busq) && isset($cat)){
 
    $q = $mysqli->query("SELECT * FROM productos WHERE name like '%$busq%' AND id_categoria = '$cat'");
}elseif(isset($cat) && !isset($busq)){

    $q = $mysqli->query("SELECT * FROM productos WHERE id_categoria = '$cat' ");

}elseif(isset($busq) && !isset($cat)){
  redir("?p=search&busq=$busq");
}
$id_cliente = $_SESSION['id_cliente'];
check_user('miscompras');
$s = $mysqli->query("SELECT * FROM compra WHERE id_cliente = '$id_cliente' ORDER BY fecha ASC");
if(mysqli_num_rows($s)>0){
    ?>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Tutorial DataTables</title>
      
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- CSS personalizado --> 
    <link rel="stylesheet" href="main.css">  
      
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
  </head>
    
  <body> 
         
   
     
    <!--Ejemplo tabla con DataTables-->
    <div class="container">

<style type="text/css">
    .square {
  width: .7em;
  height: .7em;
  margin: .5em;
  display: inline-block;
}
table.dataTable thead>tr>th.sorting_asc, table.dataTable thead>tr>th.sorting_desc, table.dataTable thead>tr>th.sorting, table.dataTable thead>tr>td.sorting_asc, table.dataTable thead>tr>td.sorting_desc, table.dataTable thead>tr>td.sorting {
    /* padding-right: 30px; */
    padding: 17px;
    vertical-align: inherit;
    text-align: center;
}
.page-header__title h1 {
    margin-bottom: 0;
    font-weight: 100!important;
    font-size: 30px;
}
</style>
        <div class="row">
                <div class="col-lg-12">
                     <div class="page-header">
                <div class="page-header__container container" style="   padding: 10px 0px 0px 0px;font-size: 24px;
    font-weight: 700;">
                
                    
                    <div class="d-sm-flex align-items-center justify-content-between mb-4" style="    margin-bottom: 1rem!important;">
           <h1 class="h3 mb-0 text-gray-800" ></h1>Mis compras</h1> 
        
           
            <a href="?p=gastos" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-clipboard-list"></i>&nbsp;&nbsp; Administrar gastos</a>
          </div>
                </div>
            </div>
               <label>• Gastos esta semana</label>
                        <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2" style="box-shadow: none!important;border: 1px solid #bbbbc3;">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Ventas en OPEN</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">$ <?=number_format($data30['f30'])?></div>
                    </div>
                    <div class="col-auto">
                         <img src="categorias/compras (3).png" style="    width: 50px;">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2" style="box-shadow: none!important;border: 1px solid #bbbbc3;">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Otros Gastos</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">$ <?=number_format($data30['f30'])?></div>
                    </div>
                    <div class="col-auto">
                     <img src="contabilidad.png" style="width:50px;">
                    </div>
                  </div>
                  
                </div><center>Ver y/o añadir gastos</center>
              </div>
              
            </div>
            <label>• Gastos por mes</label>
            <form method="post" action="">
    <div class="row" style="    width: 100%;
    padding-right: 15px;
    padding-left: 15px;
    margin-right: auto;
    margin-left: auto;">
      
      <div class="col-md-5" style="flex: 0 0 49.666667%;
    max-width: 50.666667%;">
          <?php
          if(!isset($buscar)){
              $catw=date('m');
              
          }

          ?>
      <select id="categoria" name="mesr" class="form-control">

      <option <?php if($catw == 0) { echo "selected"; } ?> value="0">Escoger mes:</option>
      <option <?php if($catw == 1) { echo "selected"; } ?> value="1">Enero</option>
      <option <?php if($catw == 2) { echo "selected"; } ?> value="2">Febrero</option>
      <option <?php if($catw == 3) { echo "selected"; } ?> value="3">Marzo</option>
      <option <?php if($catw == 4) { echo "selected"; } ?> value="4">Abril</option>
      <option <?php if($catw == 5) { echo "selected"; } ?> value="5">Mayo</option>
      <option <?php if($catw == 6) { echo "selected"; } ?> value="6">Junio</option>
      <option <?php if($catw == 7) { echo "selected"; } ?> value="7">Julio</option>
      <option <?php if($catw == 8) { echo "selected"; } ?> value="8">Agosto</option>
      <option <?php if($catw == 9) { echo "selected"; } ?> value="9">Sepetiembre</option>
      <option <?php if($catw == 10) { echo "selected"; } ?> value="10">Octubre</option>
      <option <?php if($catw == 11) { echo "selected"; } ?> value="11">Noviembre</option>
      <option <?php if($catw == 12) { echo "selected"; } ?> value="12">Dicimbre</option>


        

        </select>
      </div>
      <div class="col-md-2" style="
    width: 50%;    padding: 10px;
">
        <button type="submit" class="btn btn-prmiary" name="buscar" style="
    background: #36373a;
    color: white;
padding:0px;
    width: 61%;
"><i class="fa fa-serch"></i> Filtrar</button>
      </div>
    </div>
  </form>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2" style="box-shadow: none!important;border: 1px solid #bbbbc3;">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Ventas en OPEN</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">$ <?=number_format($data30['f30'])?></div>
                    </div>
                    <div class="col-auto">
                      <img src="categorias/compras (3).png" style="    width: 50px;">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2" style="box-shadow: none!important;border: 1px solid #bbbbc3;">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Otros Gastos</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">$ <?=number_format($data30['f30'])?></div>
                    </div>
                    <div class="col-auto">
                 <img src="contabilidad.png" style="width:50px;">
                    </div>
                  </div>
                </div><center>Ver y/o añadir gastos</center>
              </div>
              
            </div>
            <h1 style="font-size:25px!important">Recuerdo de facturas</h1>
                    <div class="table-responsive" style="border:2px solid #d0d0d6;
    padding: 12px 0px 0px 0px;">        
                        <table id="example" class="table table-striped table-bordered" style="width:100%;">
                        <thead>
                            <tr>
                                <th style="padding: 0px 8px 0px 9px;">Fecha a pagar</th>
                                <th>Descripción</th>
                                <th style="width: 170px!important;padding: 0px 8px 0px 9px;">Estado</th>
                                <th style="padding: 2px;padding:0px 8px 0px 9px">Monto</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                                      <?php
    while($r=mysqli_fetch_array($s)){
        ?>
            <?php
        $contador5 =0;
  $q2 = $mysqli->query("SELECT * FROM productos_compra WHERE id_compra = '".$r['id']."' ");
  while($r2=mysqli_fetch_array($q2)){
$contador5++;
}
?>

                            <tr>
                                <td>30/03/2020</td>
                                 <td>Pago de arriendo</td>
                                  <td>sin pagar</td>
                                   <td>$430,000</td>
                                </tr>
                                              <?php
    }
    ?>
                        </tbody>        
                       </table>                  
                    </div>
                </div>
        </div>  
    </div>    
      
<br><br>
                <?php
}else{
    ?>
    <center>
<img src="categorias/sin1.png" width="1000" height="500" style="
    max-width: 86%;
    height: auto;
    max-width: 100%;
    height: auto;
    padding-top: 80px;
    padding-block-end: 160px;
"></center>
    <?php
} 
?> 
    <!--Ejemplo tabla con HTML-->  
    <!--<div style="height:50px"></div> 
    <div class="container">
    <h3>Tabla con <span class="badge badge-secondary">HTML puro</span></h3>
    <div class="row">
            <div class="col-lg-12">
                <table border=1 cellpadding=1>
                    <thead>
                        <th>Nombre</th>
                        <th>País</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Juan Perez</td>
                            <td>Argentina</td>
                        </tr>
                        <tr>
                            <td>María Pía</td>
                            <td>Venezuela</td>
                        </tr>
                        <tr>
                            <td>Juan Caros</td>
                            <td>Perú</td>
                        </tr>
                    </tbody>
                </table>
            </div>
    </div>
    </div>    -->
      
      
    <!--Ejemplo tabla con bootstrap 4-->    
    <!--<div style="height:50px"></div>               
    <div class="container">
    <h3>Tabla con <span class="badge badge-secondary">BOOTSTRAP 4</span></h3>
    <div class="row">
            <div class="col-lg-12">                    
                <table class="table table-striped table-hover table-bordered">
                    <thead class="thead-dark">
                        <th>Nombre</th>
                        <th>País</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Juan Perez</td>
                            <td>Argentina</td>
                        </tr>
                        <tr>
                            <td>María Pía</td>
                            <td>Venezuela</td>
                        </tr>
                        <tr>
                            <td>Juan Caros</td>
                            <td>Perú</td>
                        </tr>
                    </tbody>
                </table>
            </div>
    </div>
    </div>-->    
      
    <!-- jQuery, Popper.js, Bootstrap JS -->
    <script src="jquery/jquery-3.3.1.min.js"></script>
    <script src="popper/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
      
    <!-- datatables JS -->
    <script type="text/javascript" src="datatables/datatables.min.js"></script>    
     
    <script type="text/javascript" src="main.js"></script>  
    
    
  </body>
</html>
