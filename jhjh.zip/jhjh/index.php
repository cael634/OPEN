<!DOCTYPE html>
<html lang="en">
  <head>
  	<style type="text/css">
  		.mu-navbar {
    padding: 10px 0 !important;
}
#mu-hero {
    background-color: #e2013b!important;
    display: inline;
    float: left;
    width: 100%;
}
.mu-about-area {
    display: inline;
    float: left;
    padding: 50px 0px 0px 0px!important;
    width: 100%;
}
ul li {
    list-style: disc  !important;

    line-height: 1.59  !important;
}
.mu-footer-top {
    background-color: #e2013b!important;
    display: inline;
    float: left;
    padding: 55px 0;
    width: 100%;
}
ul li {
    list-style: none !important;
    
    /* line-height: 1.59; */
}
.scrollToTop, .mu-testimonial-slide .slick-dots li.slick-active, #mu-callto-action {
    background-color: #323435!important;
}
#mu-from-blog {
    background-color: #fff;
    float: left;
    padding: 0px 0px 100px 0px!important;
    display: inline;
    width: 100%;
}
#mu-call-to-action {
    background-image: url(prin.png)!important;
    float: left;
    position: relative;
    width: 100%;
}
.mu-title p {
    /* height: 300px; */
    width: 627px!important;
}

element.style {
}
.mu-single-footer .list-unstyled li.media p {
    line-height: 1.5;
    margin-top: -2px!important;
    margin-bottom: 4px;
    font-size: 14px;
}
  	</style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>B-Hero : Home</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/favicon.ico"/>
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Gallery Lightbox -->
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <!-- Skills Circle CSS  -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/circlebars@1.0.3/dist/circle.css">
    <script src="https://kit.fontawesome.com/98fd34a9f5.js" crossorigin="anonymous"></script>

    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    <!-- Fonts -->

    <!-- Google Fonts Raleway -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,400i,500,500i,600,700" rel="stylesheet">
	<!-- Google Fonts Open sans -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700,800" rel="stylesheet">
 
 
	</head>
  <body>

   <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>
    </a>
  <!-- END SCROLL TOP BUTTON -->
  	
  	<!-- Start Header -->
	<header id="mu-hero" style="height: 80px">
		<div class="container" style="height: 87px;">
			<nav class="navbar navbar-expand-lg navbar-light mu-navbar">
				<!-- Text based logo -->
				<a class="navbar-brand mu-logo" href="index.html"><img src="open.png" style="width: 195px;"></a>
				<!-- image based logo -->
			   	<!-- <a class="navbar-brand mu-logo" href="index.html"><img src="assets/images/logo.png" alt="logo"></a> -->
			  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="fa fa-bars"></span>
			  </button>

			  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			    <ul class="navbar-nav mr-auto mu-navbar-nav">
			      <li class="nav-item active">
			        <a href="index.php" style="color:#000000bf">Home</a>
			      </li>
			      <li class="nav-item"><a href="/open/admin/index.php">Iniciar sesion</a></li>
			      <li class="nav-item"><a href="/open/admin/registroempresa.php">Registro</a></li>

			        <li class="nav-item"><a href="contact.html">Contactenos </a></li>
			    
			    </ul>
			  </div>
			</nav>
		</div>
	</header>
	<!-- End Header -->
<header style="background: rgb(54, 55, 58)"><div class="container" ><center><a href="/open/admin/registroempresa.php" style="color: white">Oferta de lanzamiento: <u>Primer mes gratis</u></a></center></div></header>
	<!-- Start slider area -->
	<div id="mu-slider">
		<div class="mu-slide">
			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img src="masope.png" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Mejora la experiecia de venta de tus clientes</h1>
									<p>Dales la posibilidad de conoser tu catalogo de productos en cualquier momento.</p>
									<a class="mu-primary-btn" href="/open/index.php">Ver interfas&nbsp; <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->

			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img src="admin12.png" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Conectate con todos los tipos de clintes que manejas</h1>
									<p>En OPEN te ayudamos en el pedido de tus productos alimenticios y del hogar a tiendas de abarrotes, ditribuidores, mayoristas, sepermercado,restaurantes,etc...</p>
									<a class="mu-primary-btn" href="#">Read more <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->

			<!-- Start single slide  -->
			<div class="mu-single-slide">
				<img src="inter.png" alt="slider img">
				<div class="mu-single-slide-content-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mu-single-slide-content">
									<h1>Diles a tus clientes que pueden pedir tus productos desde Open</h1>
									<p>Es hora de que les ofrescas a tus clientes un nuevo medio para que puedan realizen pedidos</p>
									<a class="mu-primary-btn" href="#">Read more <span class="fa fa-long-arrow-right"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End single slide  -->
		</div>
	</div>
	<!-- End Slider area -->

	
	<!-- Start main content -->
	<main>
		<!-- Start About -->
		<section id="mu-about">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-about-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>¿Que hacemos en Open?</h2>
										<p>Prover un canal de pedidos a empresas de alimentos y productos para el hogar con sus clientes como  tiendas de abarrotes, mayoristas, supermercados, restaurantes,etc...</p>
									</div>
								</div>
							</div>
							<!-- Start Feature Content -->
							<div class="row">
								<div class="col-md-6">
									<div class="mu-about-left">
										<img class="" src="prin.png" alt="img">
									</div>
								</div>
								<div class="col-md-6">
									<div class="mu-about-right">
										<ul>
											<li>
												<h3>Mejora la experiencia de tus clientes:</h3>
												<p>Es hora de que tus clientes puedan realizar pedidos y ver tu catalogo de productos en cualquier momento.</p>
											</li>
											<li>
												<h3>Te ofrecemos:</h3>
												<p>Una plataforma en la que podras publicar tus productos y de forma eficiente administrar los pedidos y la entrega.<br>Tambien por medio de tablas y graficos evaluaras la logistica, tus ventas totales y de cada producto.</p>
											</li>
											<li>
												<h3>Beneficios:</h3>
												<p>Estaras en todo momento para tus clientes y tu catalogo, podras faciliar la logistica de entrega y obtener datos importantes de tus ventas. </p>
											</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- End Feature Content -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End About -->

		<!-- Call to Action -->
		<div id="mu-call-to-action">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-call-to-action-area">
							<div class="mu-call-to-action-left">
								<h2>Comienza a vender tus productos desde Open</h2>
								<p>Tu catalogo disponible las 24 hora a tus clientes</p>
							</div>
							<a href="/open/admin/index.php" class="mu-primary-btn mu-quote-btn">Comenzar mes gratis <i class="fa fa-long-arrow-right"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Start Services -->
		<section id="mu-service">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-service-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Nuestros servicios</h2>
										<p>Brindamos herramientas si tu metodo de entrega es por rutas o normal</p>
									</div>
								</div>
							</div>
							<!-- Start Service Content -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-service-content">
										<div class="row">
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fas fa-map-marker-alt"></i></div>
													<div class="mu-single-service-content">
														<h3>Mecanismo de Rutas</h3>
														<p>De manera facil puedes adaptar tu modelo de entrega por rutas y podras administrar tus clientes como lo hacias antes.Asiganle a a la cuneta del clinete y añade diase antelacion para realiza el peddios a esta ruta y automaticamnete se asignara los pedidos a la ruta</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fas fa-route"></i></div>
													<div class="mu-single-service-content">
														<h3>Seguimento de rutas</h3>
														<p>Te damos la posiblidad de ver la cantidad de pedidos entregados y faltantes de cada ruta en el instante que tu desees</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fas fa-mobile"></i></div>
													<div class="mu-single-service-content">
														<h3> APP OPEN repartidor</h3>
														<p>Te ayudamos con la logistica de la entrega dando la posiblidad de que uses la plataforma que muestra los pedidos a relizar en determiando dia o ruta .</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fas fa-chart-bar"></i></div>
													<div class="mu-single-service-content">
														<h3>Estadistica por productos</h3>
														<p>Observa las estadisticas de la cantidad de productos vendidos y el monto que suman estos por diferntes intervalos de tiempo,como tambein compara tus productos estrella por porcentahje de vantas de cada produto del total de todos .</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fas fa-chart-line"></i></div>
													<div class="mu-single-service-content">
														<h3>Estadisticas por ventas</h3>
														<p>Te ofrecemos informecion estadidtica con graficas y tablas de como han sido tusventas en determinado tiempo.</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
											<!-- Start single service -->
											<div class="col-md-4">
												<div class="mu-single-service">
													<div class="mu-single-service-icon"><i class="fas fa-clipboard-check"></i></div>
													<div class="mu-single-service-content">
														<h3>Maneja tus ventas</h3>
														<p>Sea por rutas o no tu logistica, ten la posiblidad de observar todos las ventas relizadas por cada dia y el estadoque esta el pedidos</p>
													</div>
												</div>
											</div>
											<!-- End single service -->
										</div>
									</div>
								</div>
							</div>
							<!-- End Service Content -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Services -->

		<!-- Start Video -->
	
		<!-- End Video -->

		<!-- Start Portfolio -->
		<section id="mu-portfolio">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-portfolio-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Nuestra interfaz</h2>
										<p>Sea tu medelo de entrega rutas o no obtienes datos importantes para tu logistica, evaluación de ventas totales y por producto.</p>
									</div>
								</div>
							</div>

							<div class="row">
									<!-- Start Portfolio Filter -->
									<div class="mu-portfolio-filter-area">
										<ul class="mu-simplefilter">
							                <li class="active" data-filter="all">Todos<span>/</span></li>
							                <li data-filter="1">Diseño de la web<span>/</span> </li>
							                <li data-filter="2">Pedidos<span>/</span></li>
							                <li data-filter="3">Rutas<span>/</span></li>
							                <li data-filter="4">App OPEN Repartidor <span>/</span> </li>
							                <li data-filter="5">Estadisticas</li>
							            </ul>
									</div>

									<!-- Start Portfolio Content -->
									<div class="mu-portfolio-content">
										<div class="filtr-container">
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
                                               <a class="mu-imglink" href="openpla.png" title="PAINTING">
                                                    <img class="img-responsive" src="openpla.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Tienda</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
                                               <a class="mu-imglink" href="inter.png" title="PAINTING">
                                                    <img class="img-responsive" src="inter.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Inicio empresa</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
                                               <a class="mu-imglink" href="otra.png" title="PAINTING">
                                                    <img class="img-responsive" src="otra.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Interfaz</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
                                               <a class="mu-imglink" href="carrito.png" title="PAINTING">
                                                    <img class="img-responsive" src="carrito.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Carrito</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>

							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
							                   <a class="mu-imglink" href="compra.png" title="PAINTING">
								                   	<img class="img-responsive" src="compra.png" alt="image">
								                   	<div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Compra</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>

                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
                                               <a class="mu-imglink" href="app.png" title="PAINTING">
                                                    <img class="img-responsive" src="app.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">App</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>

                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
                                               <a class="mu-imglink" href="listo.png" title="PAINTING">
                                                    <img class="img-responsive" src="listo.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">App compra</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>

							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="5">
							                    <a class="mu-imglink" href="admin12.png" title="BRANDING">
							                    	<img class="img-responsive" src="admin12.png" alt="image">
								                    <div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Estadisticas</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                    </a>
							                </div>

							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
							                    <a class="mu-imglink" href="produc.png" title="E-COMMERCE">
							                    	<img class="img-responsive" src="produc.png" alt="image">
								                    <div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">Estadistica</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                    </a>
							                </div>

							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                    <a class="mu-imglink" href="assets/images/portfolio/img-4.jpg" title="WEB DESIGN">
							                    	<img class="img-responsive" src="assets/images/portfolio/img-4.jpg" alt="image">
								                    <div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">WEB DESIGN</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                    </a>
							                </div>

							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
							                    <a class="mu-imglink" href="assets/images/portfolio/img-5.jpg" title="MOBILE DEVELOPMENT">
							                    	<img class="img-responsive" src="assets/images/portfolio/img-5.jpg" alt="image">
								                    <div class="mu-filter-item-content">
								                    	 <h4 class="mu-filter-item-title">MOBILE DEVELOPMENT</h4>
								                    	 <span class="fa fa-long-arrow-right"></span>
								                    </div>
							                    </a>
							                </div>

							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="5">
							                   <a class="mu-imglink" href="assets/images/portfolio/img-6.jpg" title="BRANDING">
								                   	<img class="img-responsive" src="assets/images/portfolio/img-6.jpg" alt="image">
								                    <div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">BRANDING</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
								                </a>
							                </div>

							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
							                   <a class="mu-imglink" href="assets/images/portfolio/img-7.jpg" title="E-COMMERCE">
								                   	<img class="img-responsive" src="assets/images/portfolio/img-7.jpg" alt="image">
								                    <div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">E-COMMERCE</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                   </a>
							                </div>

							                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
							                    <a class="mu-imglink" href="assets/images/portfolio/img-8.jpg" title="PAINTING">
							                    	<img class="img-responsive" src="assets/images/portfolio/img-8.jpg" alt="image">
								                    <div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">PAINTING</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                    </a>
							                </div>

							                  <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
							                    <a class="mu-imglink" href="assets/images/portfolio/img-4.jpg" title="WEB DESIGN">
							                    	<img class="img-responsive" src="assets/images/portfolio/img-4.jpg" alt="image">
								                    <div class="mu-filter-item-content">
								                    	<h4 class="mu-filter-item-title">WEB DESIGN</h4>
								                    	<span class="fa fa-long-arrow-right"></span>
								                    </div>
							                    </a>
							                </div>

							            </div>
									</div>
									<!-- End Portfolio Content -->
								</div>
							
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Portfolio -->


		<!-- End Counter -->

		<!-- Start Pricing Table -->
		<section id="mu-pricing">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-pricing-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Nuestra tabla de precios</h2>
										<p>Nuestros precios se ajustan a las distintas necesidades de nuestros clientes.</p>
									</div>
								</div>
								<div class="col-md-12">
									<div class="mu-pricing-content">
										
										
<div class="pricing-table">
    <div class="plan">
        <h3 class="plan__name">Mayorista</h3><as style="font-size:13px">Numero de pedidos mensual esta entre</as><span class="plan__price">75-200</span>
        <ul class="plan__features">
            <li>Las ventas menores de <strong>$25,000 </strong> no tienen comision </liR>
            <li>Para ventas entre  <strong>$30,000 y $50,000 </strong>  la comision es de $350 por cada venta</li>
            <li>Para ventas mayores a <strong>$50,000 </strong>  la comision es de <strong>$500 </strong>  por cada venta</li>
        </ul><strong>Oferta de lanzamiento:</strong><br><a class="signup" href="/open/admin/registroempresa.php">Pruebalo, el primer es gratis</a></div>
    <div class="plan selected">
        <h3 class="plan__name">Empresa</h3><as style="font-size:13px">Numero de pedidos mensual es mayor a</as><span class="plan__price"><200</span>
        <ul class="plan__features">
            <li>Las ventas menores de <strong>$30,000 </strong> no tienen comision </li>
            <li>Para ventas entre <strong>$30,000 y $50,000 </strong> la  comision es de $300 por cada venta</li>
            <li>Para ventas mayores a <strong>$50,000 </strong>  la comision es de <strong>$450 </strong>  por cada venta</li>
        </ul><strong>Oferta de lanzamiento:</strong><br><a class="signup" href="/open/admin/registroempresa.php">Pruebalo, el primer es gratis</a></div>
    <div class="plan">
        <h3 class="plan__name">Mircroempresa</h3><as style="font-size:13px">Numero de pedidos mensual esta entre</as><span class="plan__price">0-75</span>
        <ul class="plan__features">
            <li>Las ventas menores de <strong>$12,500 </strong> no tienen comision </li>
            <li>Para ventas entre  <strong>$30,000 y $50,000 </strong>  la comision es de $400 por cada venta</li>
            <li>Para ventas mayores a <strong>$50,000 </strong>  la comision es de <strong>$600 </strong>  por cada venta</li>

        </ul><strong>Oferta de lanzamiento:</strong><br><a><a class="signup" href="/open/admin/registroempresa.php">Pruebalo, el primer es gratis</a></div>
</div>
<style type="text/css">
    @import 'https://fonts.googleapis.com/css?family=Droid+Sans:400,700';
 html {
     -webkit-box-sizing: border-box!important;
     -moz-box-sizing: border-box!important;
     box-sizing: border-box;
}
 *, *:before, *:after {
     box-sizing: inherit !important;
}
 body {
     font-family: 'Droid Sans', sans-serif !important;
     font-size: 100% !important;
     color: #232323 !important;
}

 @media (min-width: 600px) {
     .pricing-table {
         display: flex!important;
         justify-content: space-between!important;
    }
}
.pricing-table {
    width: 100%!important;
    max-width: 1010px!important;
    padding: 0px 0px!important;
    margin: -11px 5px 7px 40px;
}
.mu-portfolio-area {
    display: inline;
    float: left;
    padding: 0px 30px 100px 0px!important;
    width: 100%;
}
.mu-footer-bottom {
    background-color: #232729;
    display: inline;
    padding: 20px 0;
    float: left;
    width: 100%;
}
 .plan {
     background-image: linear-gradient(180deg, #f3f2f9 28%, #fff 28%)!important;
     border: 1px solid #c4c4c4!important;
     border-radius: 0.25em!important;
     box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.3)!important;
     padding: 12px 0px!important;
     margin: 20px 0!important;
     text-align: center!important;
}
 @media (min-width: 600px) {
     .plan {
         width: 32%!important;
             height: 570px!important;
    }
     .plan.selected {
         box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.5)!important;
         width: 34%!important;
         margin-top: -10px!important;
         margin-bottom: -10px!important;
    }
}
 .plan.selected {
     background-image: linear-gradient(180deg, #e3e1f1 28%, #fff 28%)!important;
}
 .plan__name {
     font-weight: 300!important;
}
 .plan__price {
     display: block!important;
     color: #7b7b7b!important;
     width: 80px!important;
     height: 80px!important;
     line-height: 80px !important;
     margin: 30px auto 60px !important;
     background-color: #fff !important;
     text-align: center !important;
     font-size: 1.5em !important;
     font-family: Georgia, serif !important;
     border-radius: 50% !important;
     box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.3) inset, 0px 0px 0px 10px #fff, 0px 0px 10px 11px rgba(0, 0, 0, 0.4) !important;
}
 .plan__features {
     margin: 0 0 30px 0 !important;

     padding: 0 !important;
     background-color: #fff !important;
     list-style-type: none!important;
}
 .plan__features li {
     padding: 10px 10px !important;
     border-top: 1px solid #c4c4c4 !important;
     font-size: 0.875em !important;
}
 .plan .signup {
     display: inline-block !important;
     padding: 10px 25px !important;
     text-decoration: none !important;
     color: #fff !important; 
     background-color: #05c314!important;
     border-radius: 3px !important;
     font-size: 12px !important;
     text-transform: uppercase !important;
}
 
</style>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Pricing Table -->

		<!-- End Client Testimonials -->

		<!-- Start from blog -->
		<section id="mu-from-blog">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-from-blog-area">
							<!-- Title -->
							<div class="row">
								<div class="col-md-12">
									<div class="mu-title">
										<h2>Caracteristicas</h2>
										<p>Le ofrecemos a tus clientes una plataorma que mejore su experiencia de compra mientras ayudamos tu logistica.</p>
									</div>
								</div>
								<div class="col-md-12">
									<div class="mu-from-blog-content">
										<div class="row">
											<div class="col-md-4">
												<article class="mu-blog-item">
													<a href="#"><img src="assets/images/blog-img-1.jpg" alt="blgo image"></a>
													<div class="mu-blog-item-content">
														<ul class="mu-blog-meta">
															<li>BY: ADMIN </li>
															<li><a href="#"><i class="fa fa-comment-o"></i>26</a></li>
															<li><i class="fa fa-heart-o"></i>250</li>
														</ul>
														<h2 class="mu-blog-item-title"><a href="#">Seeing the big picture of information and information management</a></h2>
														<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis. </p>
														<a class="mu-blg-readmore-btn" href="blog-single.html">Read more <i class="fa fa-long-arrow-right"></i></a>
													</div>
												</article>
											</div>
											<div class="col-md-4">
												<article class="mu-blog-item">
													<a href="#"><img src="assets/images/blog-img-2.jpg" alt="blgo image"></a>
													<div class="mu-blog-item-content">
														<ul class="mu-blog-meta">
															<li>BY: ADMIN </li>
															<li><a href="#"><i class="fa fa-comment-o"></i>26</a></li>
															<li><i class="fa fa-heart-o"></i>250</li>
														</ul>
														<h2 class="mu-blog-item-title"><a href="#">Vestibulum lacinia elit sed elit ultrices consequat.</a></h2>
														<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis. </p>
														<a class="mu-blg-readmore-btn" href="blog-single.html">Read more <i class="fa fa-long-arrow-right"></i></a>
													</div>
												</article>
											</div>
											<div class="col-md-4">
												<article class="mu-blog-item">
													<a href="#"><img src="assets/images/blog-img-3.jpg" alt="blgo image"></a>
													<div class="mu-blog-item-content">
														<ul class="mu-blog-meta">
															<li>BY: ADMIN </li>
															<li><a href="#"><i class="fa fa-comment-o"></i>26</a></li>
															<li><i class="fa fa-heart-o"></i>250</li>
														</ul>
														<h2 class="mu-blog-item-title"><a href="#">Aliquam consectetur sem sed ante semper, ut convallis risus ullamcorper.</a></h2>
														<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis. </p>
														<a class="mu-blg-readmore-btn" href="blog-single.html">Read more <i class="fa fa-long-arrow-right"></i></a>
													</div>
												</article>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End from blog -->

	
		<!-- End Newsletter -->

		<!-- Start Clients -->

		<!-- End Clients -->

	</main>
	
	<!-- End main content -->	
			
			
	<!-- Start footer -->
	<footer id="mu-footer">
		<div class="mu-footer-top">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<div class="mu-single-footer">
							<img class="mu-footer-logo" src="open.png" alt="logo">
							<p>Le ofrecemos a tus clientes una plataorma que mejore su experiencia de compra mientras ayudamos tu logistica. </p>
							
						</div>
					</div>
					<div class="col-md-3">
						<div class="mu-single-footer">
							<h3>Servicios</h3>
							<ul class="list-unstyled">
							  	<li class="media">
								   <span><i class="fas fa-building"></i></span>
								    <div class="media-body">
								    	<p><strong>Empresas: </strong>Plataforma de venta de productos, manejo de pedidos y estaditicas de ventas.</p>
								   
								    </div>
							  	</li>
							  	<li class="media">
								   	<span><i class="fas fa-store"></i></span>
								    <div class="media-body">
								    	<p><strong>Clientes: </strong>Plataforma para facilitar sus compras y su historial de pedidos.</p>
								    
								    </div>
							  	</li>
							</ul>
						</div>
					</div>
					<div class="col-md-3">
						<div class="mu-single-footer">
							<h3>Links</h3>
							
								<li>open.com.se</li>
                                <li>Inicio de empresas</li>
                                <li>Regitro</li>
                                <li>APP</li>
								
							</ul>
						</div>
					</div>
					<div class="col-md-3">
						<div class="mu-single-footer">
							<h3>Informción de contacto</h3>
							<ul class="list-unstyled">
							  <li class="media">
							    <span><i class="fas fa-envelope"></i></span>
							    <div class="media-body">
							    	<p>servicioalcliente@open.com.se</p>
							    </div>
							  </li>
							  <li class="media">
							    <span class="fa fa-phone"></span>
							    <div class="media-body">
							       <p>Cel: 316-3779791</p>
							   
							    </div>
							  </li>
							
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="mu-footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-footer-bottom-area">
							<p class="mu-copy-right">&copy; Copyright <a rel="nofollow" href="http://markups.io">markups.io</a>. All right reserved.</p>
						</div>
					</div>
				</div>
			</div>
		</div>

	</footer>
	<!-- End footer -->

	
	<!-- JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
	<!-- Slick slider -->
    <script type="text/javascript" src="assets/js/slick.min.js"></script>
    <!-- Progress Bar -->
    <script src="https://unpkg.com/circlebars@1.0.3/dist/circle.js"></script>
    <!-- Filterable Gallery js -->
    <script type="text/javascript" src="assets/js/jquery.filterizr.min.js"></script>
    <!-- Gallery Lightbox -->
    <script type="text/javascript" src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Counter js -->
    <script type="text/javascript" src="assets/js/counter.js"></script>
    <!-- Ajax contact form  -->
    <script type="text/javascript" src="assets/js/app.js"></script>
    
	
    <!-- Custom js -->
	<script type="text/javascript" src="assets/js/custom.js"></script>

	<!-- About us Skills Circle progress  -->
	<script>
		// First circle
	    new Circlebar({
        element : "#circle-1",
        type : "progress",
	      maxValue:  "90"
	    });
		
		// Second circle
	    new Circlebar({
        element : "#circle-2",
        type : "progress",
	      maxValue:  "84"
	    });

	    // Third circle
	    new Circlebar({
        element : "#circle-3",
        type : "progress",
	      maxValue:  "60"
	    });

	    // Fourth circle
	    new Circlebar({
        element : "#circle-4",
        type : "progress",
	      maxValue:  "74"
	    });

	</script>
    
  </body>
</html>