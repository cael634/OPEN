<!DOCTYPE html>
<html lang="en">
  <head>
    <style type="text/css">
      .mu-navbar {
    padding: 10px 0 !important;
}
.mu-about-right ul li {
    list-style: none;
    float: left;
    margin-bottom: 10px!important;
}
.mu-title {
    display: inline;
    float: left;
    text-align: center;
    width: 100%;
    margin-bottom: 15px!important;
    padding: 0 25%;
}
.mu-about-right ul li h3 {
    border-bottom: 3px solid #e5e5e5;
    color: #323232;
    font-size: 17px!important;
    display: inline-block;
    padding-bottom: 5px;
    margin-bottom: 15px;
}
.mu-single-slide-content-area {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    width: 100%;
    z-index: 99;
    padding: 5% 0%!important;
}
#mu-hero {
    background-color: #e2013b!important;
    display: inline;
    float: left;
    width: 100%;
.mu-title p {
    /* height: 300px; */
    width: auto!important;
}

.mu-single-slide-content p {
    margin-bottom: 0;
    font-size: 15px!important;
}
.mu-about-area {
    display: inline;
    float: left;
    padding: 50px 0px 0px 0px!important;
    width: 100%;
}
ul li {
    list-style: disc  !important;

    line-height: 1.59  !important;
}
.mu-footer-top {
    background-color: #e2013b!important;
    display: inline;
    float: left;
    padding: 55px 0;
    width: 100%;
}
ul li {
    list-style: none !important;
    
    /* line-height: 1.59; */
}
.scrollToTop, .mu-testimonial-slide .slick-dots li.slick-active, #mu-callto-action {
    background-color: #323435!important;
}
#mu-from-blog {
    background-color: #fff;
    float: left;
    padding: 0px 0px 100px 0px!important;
    display: inline;
    width: 100%;
}
#mu-call-to-action {
    background-image: url(masope.png)!important;
    float: left;
    position: relative;
    width: 100%;
}


element.style {
}
.mu-single-footer .list-unstyled li.media p {
    line-height: 1.5;
    margin-top: -2px!important;
    margin-bottom: 4px;
    font-size: 14px;
}
    </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>OPEN para empresas</title>
    <!-- Favicon -->
   <link rel="icon" type="image/png" href="open12498.png">
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Gallery Lightbox -->
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <!-- Skills Circle CSS  -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/circlebars@1.0.3/dist/circle.css">
    <script src="https://kit.fontawesome.com/98fd34a9f5.js" crossorigin="anonymous"></script>

    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    <!-- Fonts -->

    <!-- Google Fonts Raleway -->
  <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,400i,500,500i,600,700" rel="stylesheet">
  <!-- Google Fonts Open sans -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700,800" rel="stylesheet">
 
 
  </head>
  <body>

   <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>
    </a>
  <!-- END SCROLL TOP BUTTON -->
    
    <!-- Start Header -->
  <header id="mu-hero" style="height: 75px">
    <div class="container" style="height: 87px;">
      <nav class="navbar navbar-expand-lg navbar-light mu-navbar">
        <!-- Text based logo -->
        <a class="navbar-brand mu-logo" href="index.html"><img src="open.png" style="width: 170px;  "></a>
        <!-- image based logo -->
          <!-- <a class="navbar-brand mu-logo" href="index.html"><img src="assets/images/logo.png" alt="logo"></a> -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="fa fa-bars"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto mu-navbar-nav">
            <li class="nav-item active">
              <a href="index.php" style="color:#000000bf">Home</a>
            </li>
            <li class="nav-item"><a href="/admin/index.php">Iniciar sesion</a></li>
            <li class="nav-item"><a href="/admin/registroempresa.php">Registro</a></li>

            
          
          </ul>
        </div>
      </nav>
    </div>
  </header>
  <!-- End Header -->

  <!-- Start slider area -->
  <div id="mu-slider">
    <div class="mu-slide">
      <!-- Start single slide  -->
      <div class="mu-single-slide">
        <img src="masope.png" alt="slider img" style="    height: 390px;">
        <div class="mu-single-slide-content-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mu-single-slide-content">
                      <h1>Tus clientes pueden realizarte pedidos desde OPEN</h1>
                  <p>Ofréceles facilidad para realizar su proceso de abastecimiento</p>
                  
                  <a class="mu-primary-btn" href="https://open.com.se/?p=productos">Ver interfas&nbsp; <span class="fa fa-long-arrow-right"></span></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End single slide  -->

      <!-- Start single slide  -->
      <div class="mu-single-slide">
        <img src="admin12.png" alt="slider img" style="    height: 390px;">
        <div class="mu-single-slide-content-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mu-single-slide-content">
                  <h1>Conectate con todos los tipos de clientes que manejas</h1>
                  <p>En OPEN te ayudamos en la toma pedido de tus productos alimenticios y del hogar a tiendas de abarrotes, distribuidores, mayoristas, supermercado, restaurantes, etc...</p>
                  <a class="mu-primary-btn" href="/admin/registroempresa.php">Registrarse&nbsp; <span class="fa fa-long-arrow-right"></span></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End single slide  -->

      <!-- Start single slide  -->
      <div class="mu-single-slide">
        <img src="inter.png" alt="slider img" style="    height: 390px;">
        <div class="mu-single-slide-content-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mu-single-slide-content">
                  <h1>Mejora la experiecia de venta de tus clientes</h1>
                  <p>Dales la posibilidad de conoser tu catalogo de productos en cualquier momento y estar al pendiente de tus nuevos productos.</p>
                  <a class="mu-primary-btn" href="/admin/registroempresa.php">Registrarse <span class="fa fa-long-arrow-right"></span></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End single slide  -->
    </div>
  </div>
  <!-- End Slider area -->

  
  <!-- Start main content -->
  <main>
    <!-- Start About -->
    <section id="mu-about">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-about-area" style="    padding: 25px 0px 6px 0px;
"><br>
              <!-- Title -->
              <div class="row">
                <div class="col-md-12">
                  <div class="mu-title" style="    padding: 0 0%;">
                    <h2>OPEN es un portal de pedidos entre empresas de alimentos y productos para el hogar, con sus clientes:</h2>
                    <p>Usa este canal de ventas para facilitar el proceso de abastecimiento de los negocios de tus clientes</p>
                  </div>
                </div>
              </div>
              <style>
                  h3 {
    font-size: 24px!important;
}
              </style>
              <!-- Start Feature Content -->
              <div class="row">
                <div class="col-md-6"  style="flex: 0 0 60%;
    max-width: 60%;margin: 35px 0px 0px 0px;">
                  <div class="mu-about-left">
                    <img class="" src="imagne.png" alt="img">
                  </div>
                </div>
                <div class="col-md-6" style="flex: 0 0 40%;
    max-width: 40%;">
                  <div class="mu-about-right">
                    <ul>
                      <li>
                        <h3>Facilita el proceso de abastecimiento de tus clientes</h3>
                        <p>Ofrece a tus clientes un canal donde puedan realizar la mayoría de sus pedidos desde una misma plataforma, así facilitaras su proceso de abasteciendo y el evaluó de su historial de gastos. </p>
                      </li>
                      <li>
                        <h3>Te ofrecemos:</h3>
                        <p>Una plataforma en la que podrás publicar tus productos y de forma eficiente administrar los pedidos y si desea tambien la entrega. <br>Por medio de tablas y gráficos evaluaras tus ventas totales y de cada producto.</p>
                      </li>
                      <li>
                        <h3>Nos adaptamos a tu modelo de pedidos</h3>
                        <p>Nuestra plataforma cuenta con distintas opciones para adaptarse a tu modelo de toma de pedidos. Pueden realizar pedidos todos los tipos de clientes que manejas como <b>tiendas de abarrotes, distribuidores, mayoristas, supermercado y restaurantes.</b></p>
                      </li>
                      
                    </ul>
                  </div>
                </div>
              </div>
              <!-- End Feature Content -->
            </div>
          </div>
        </div>
      </div>
        
    </section>
  
    <!-- End About -->
    <!-- Start About -->
    <section id="mu-about">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-about-area" style="padding: 22px;">
              <!-- Title -->
              <div class="row">
                <div class="col-md-12">
                  <div class="mu-title" style="padding: 0%">
                    <h2 style="font-size: xxx-large;">Nuestra interfaz</h2>
                    <p>Adapatamos nuevas herramientas personalizadas para cada empresa gratuitamente. App para compras, web, plataforma de empresas, automatizacion de pedidos, logistica y app para repartidores</p>
                  </div>
                </div>
              </div>
               <div class="row">
                <div class="col-md-12">
                  <div class="mu-title" style="    padding: 0 0%;">
                    <h2>OPEN para tus clientes</h2>
                    <p>En esta interfaz tus clientes podran observar y realizar pedidos las 24 horas cualqiuer dia de la semana, en cualquier dispositivo conectado a internet.</p>
                  </div>
                </div>
              </div>
              <!-- Start Feature Content -->
              <div class="row">
                <div class="col-md-6" style="flex: 0 0 60%;
    max-width: 60%;">
                  <div class="mu-about-left">
                    <img class="" src="imagne12.png" alt="img">
                  </div>
                </div>
                <div class="col-md-6" style="flex: 0 0 40%;
    max-width: 40%;">
                  <div class="mu-about-right">
                    <ul>
                      <li>
                        <h3>¡En cualquier dispositivo!</h3>
                        <p>Tus clientes tendrán a la mano el catálogo de tus productos y recibirán notificaciones de nuevos productos, asegurando una eficiente campaña de marketing desde el distribuidor.</p>
                      </li>
                      <li>
                        <h3>En cualquier momento</h3>
                        <p>Tus clientes podrán realizarte pedidos al momento en que vean que necesitan reabastecerse, logrando así de manera eficaz no perder ventas de tus productos.</p>
                      </li>
                     
                    </ul>
                  </div>
                </div>
              </div>
              <br><br>
              <!-- End Feature Content -->
               <!-- Start Feature Content -->
              <div class="row">
                   <div class="col-md-6" style="flex: 0 0 50%;
    max-width: 50%;">
                  <div class="mu-about-right">
                    <ul>
                      <li>
                        <h3>Compra desde la App OPEN</h3>
                        <p>Una App dedicada a los compradores, podrán realizar compras y ver el catálogo de tus productos.</p>
                      </li>
                      <li>
                        <h3>Herramientas utiles para la compra</h3>
                       <p>Si la empresa desea puede activar a sus clientes las siguientes herramientas:
                        <br><b>* Manejo de estados</b>, para facilidad y eficiencia de la empresa tiene la opción de que sus mismos clientes cambien el estado de la compra a terminado.
                        <br><b>* Devoluciones</b>, para productos que caducaron o fueron entregados en mal estado.
                        <br><b>* Chat (Servicio al cliente)</b>, las empresas tienen la posibilidad de habilitar comunicación por medio de chat con sus clientes, logrando así de manera efectiva resolver dudas, recibir sugerencias y/o quejas. Muy importante para que tus clientes tengan la facilidad de comunicarse y la empresa pueda mejorar aun mas su servicio.
                        <br><b>* Informar ausencia</b>, tus clientes podrán informar que el día de la entrega en un lapso de tiempo no estarán presentes para recibir el pedido.
                        <br><b>* Pedido cerca</b>, puedes cambiar el estado de la compra a próximo, este estado significa en un promedio de 5 minutos llegará su pedido, lo que reducirá tiempo de entrega ya que el cliente podrá alistar el dinero y el espacio para colocar el pedido antes de que llegue.</p>

                      </li>
                      <a href="https://play.google.com/store/apps/details?id=com.wOPEN_10934662"><img class="" src="google.png" alt="OPEN app" style="    max-width: 40%;" ></a>   
                    </ul>
                    
                  </div>
                </div>
                <div class="col-md-6" style="flex: 0 0 50%;
    max-width: 50%;padding: 0px 0px 0px 30px;">
                  <div class="mu-about-left" style="text-align: center;">
                    <img class="" src="open app.jpg" alt="img" style="max-width: 100%;
    max-height: 40%;">
                  </div>
                </div>
               
              </div>
              <br><br>
              <!-- End Feature Content -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <center> <p style="color:#007bff!important"><a href="https://open.com.se/info/app.php" style="color:#007bff!important;font-size: 22px;">Mas información sobre la web y App OPEN <i class="fa fa-long-arrow-right"></i></p></a></center>
    <!-- Call to Action -->
    <div id="mu-call-to-action" style="    background-image: url(masope.png);">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-call-to-action-area">
                            <div class="mu-call-to-action-left">
                                <h2>Comienza a tomar pedidos de tus clientes <br> desde Open</h2>
                                <p>Tu catalogo disponible las 24 hora a tus clientes</p>
                                <br>
                <p style="    font-size: 22px;">Fecha de lanzamiento 22 de junio.</p>
                            </div>
                            
                            <a href="https://open.com.se/admin/registroempresa.php" class="mu-primary-btn mu-quote-btn">Comenzar 2 meses sin ningun costo <i class="fa fa-long-arrow-right"></i></a>
                        </div>
          </div>
        </div>
      </div>
    </div>
        <section id="mu-about">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-about-area" style="    padding: 25px 0px 0px 0px;">
              <!-- Title -->
             
               <div class="row">
                <div class="col-md-12">
                  <div class="mu-title">
                    <h2>OPEN para empresas</h2>
                    <p>Contamos con una interfaz para empresas que cuenta con diferentes opciones y módulos para realizar sus ventas, podrá escoger a cuál se adapta a sus necesidades.</p>
                  </div>
                </div>
              </div>
              <!-- Start Feature Content -->
              <div class="row">
                <div class="col-md-6" style="flex: 0 0 68%;
    max-width: 68%;">
                  <div class="mu-about-left">
                    <img class="" src="interfaz78.png" alt="img">
                  </div>
                </div>
                <div class="col-md-6" style="flex: 0 0 32%;
    max-width: 32%;">
                  <div class="mu-about-right">
                    <ul>
                     
                      <li>
                        <h3>Interfaz para empresas</h3>
                        <p>La interfaz cuanta con varios módulos de los cuales puede escoger cuales se adaptan mejor a sus necesidades. El objetivo es que pueda de forma eficaz administrar sus pedidos, automatizar sus ventas, conocer el progreso de sus ventas por medio de estadísticas y tablas.<b>Dadas las diferentes capacidades de cada empresa en materia de cobertura y de puntos de distribución tiene la posibilidad de crear cuentas individuales para cada punto de distribución y adaptarse así mejor a la plataforma.</b>
                        </p>
                      </li>
                     
                    </ul>
                  </div>
                </div>
              </div>
              <br><br><br>
              <!-- End Feature Content -->
               <!-- Start Feature Content -->
              <div class="row">
                   <div class="col-md-6" style="flex: 0 0 50%;
    max-width: 50%;">
                  <div class="mu-about-right">
                    <ul>
                     
                      <li>
                        <h3>Módulos de Ventas y clientes</h3>
                        <p>
                       <b> * Modulo de pedidos:</b> De forma eficiente pude administra sus pedidos y tener información de este y del cliente.
                         <br><b>* Modulo de clientes:</b> para comodidad de sus clientes a la hora de realizar el pedido y conocer información de entrega, tiene 3 opciones:

                        <br><b>1.) Asignar días de entrega:</b> Pude añadirle a cada cliente, un día de la semana  y el número de días de antelación para hacer el pedido, si el tiempo es menor, entonces la fecha de entrega  será el día de la semana asignada más cercana, más 7 días.
                        <br><b>2.) Asignar más de un día de entrega.</b>
                        <br><b>3.) Asignar ruta:</b> desde el panel de rutas puede crear rutas y asignarle a cada cliente una de estas, así sus clientes conocerán el día de entrega de sus pedidos. Muy útil para conocer  la cantidad de cada producto a llevar en cada ruta.
                        <br><b>4.) Información de distribución:</b> añade horario de distribución y tiempo aproximado en llegar el pedido. </p>

                      </li>
          
                    </ul>
                    
                  </div>
                </div>
                <div class="col-md-6" style="flex: 0 0 50%;
    max-width: 50%;    padding: 0px 0px 0px 10px;">
                  <div class="mu-about-left" style="text-align: center;">
                    <img class="" src="infope5.png" alt="img" style="max-width: 120%;
    max-height: 40%;">
                  </div>
                </div>
               
              </div>
              <br><br><br>
                 <div class="row">
                <div class="col-md-6" style="flex: 0 0 60%;
    max-width: 60%;">
                  <div class="mu-about-left">
                    <img class=""  src="estdistica77656786.jpg" alt="img">
                  </div>
                </div>
                <div class="col-md-6" style="flex: 0 0 40%;
    max-width: 40%;">
                  <div class="mu-about-right">
                    <ul>
                      <li>
                        <h3>Módulos de Estadisticas</h3>
                        <p>En el panel de estadísticas podrás tener gráficas y tablas de tus ventas en distintos lapsos de tiempo como:
                        <br><b>• Diario.</b>
                        <br><b>• Semanal.</b>
                        <br><b>• Mensual.</b>
                        <br><b></b>De los siguientes tipos:
                        <br><b>• El total de las ventas.</b>
                        <br><b>• Por cada producto.</b>
                        <br><b>• Comparación de ventas de todos los productos en referencia con el total de las ventas.</b></p>
                      </li>
                     
                     
                    </ul>
                  </div>
                </div>
              </div>
              <br><br>
              <!-- End Feature Content -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Start Services -->
    <section id="mu-service" style="    padding: 9px 0px 13px 0px;">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-service-area">
              <!-- Title -->
              <div class="row">
                <div class="col-md-12">
                  <div class="mu-title">
                    <h2>Nuestros servicios adicionales (Gratis)</h2>
                    <p>Brindamos herramientas para hacer más eficiente la toma de pedidos y logística.</p>
                  </div>
                </div>
              </div>
              <!-- Start Service Content -->
              <div class="row">
                <div class="col-md-12">
                  <div class="mu-service-content">
                    <div class="row">
                      <!-- Start single service -->
                      <div class="col-md-4">
                        <div class="mu-single-service">
                          <div class="mu-single-service-icon"><i class="fas fa-map-marker-alt"></i></div>
                          <div class="mu-single-service-content">
                            <h3>Mecanismo de Rutas</h3>
                            <p>De manera fácil puedes adaptar tu modelo de entrega por rutas y podrás administrar tus clientes como lo hacías antes. Asígnale el día de la semana y añade días de antelación para realiza el pedido a esta ruta y automáticamente se asignará los pedidos de los clientes a esta.</p>
                          </div>
                        </div>
                      </div>
                      <!-- End single service -->
                      <!-- Start single service -->
                      <div class="col-md-4">
                        <div class="mu-single-service">
                          <div class="mu-single-service-icon"><i class="fas fa-truck-loading"></i></div>
                          <div class="mu-single-service-content">
                            <h3>Seguimento de rutas</h3>
                            <p>Te damos la posiblidad de ver la cantidad de pedidos entregados y faltantes de cada ruta en cada momento, de forma eficaz ya que se cuenta con estadisticas y tablas.</p>
                          </div>
                        </div>
                      </div>
                      <!-- End single service -->
                      <!-- Start single service -->
                      <div class="col-md-4">
                        <div class="mu-single-service">
                          <div class="mu-single-service-icon"><i class="fas fa-shipping-fast"></i></div>
                          <div class="mu-single-service-content">
                            <h3> APP OPEN repartidor</h3>
                            <p>Te ayudamos con la logística de la entrega, ofreciendo la App para repartidores donde podrás asignarles rutas o pedidos y el orden de estos, así tendrá de forma fácil y a la mano información de los pedidos a entregar, el orden de estos y su progreso de entrega.</p>
                          </div>
                        </div>
                      </div>
                      <!-- End single service -->
                      <!-- Start single service -->
                      <div class="col-md-4">
                        <div class="mu-single-service">
                          <div class="mu-single-service-icon"><i class="fas fa-mobile"></i></div>
                          <div class="mu-single-service-content">
                            <h3>App OPEN vendedor (personal de ventas)</h3>
                            <p>Esta app esta diseña para facilitar el proceso de toma de pedidos para tu personal de ventas, ya que podrás marcar la ruta de clientes a visitar y tomar su pedido. La plataforma es muy similar a la de OPEN compradores.</p>
                          </div>
                        </div>
                      </div>
                      <!-- End single service -->
                      <!-- Start single service -->
                      <div class="col-md-4">
                        <div class="mu-single-service">
                          <div class="mu-single-service-icon"><i class="fas fa-route"></i></div>
                          <div class="mu-single-service-content">
                            <h3>Rutas mas eficientes</h3>
                            <p>Con ayuda del módulo de rutas, el cual implementa Google Maps podrás trazar la ruta más eficiente, reduciendo tiempo y distancia de recorrido, lo cual simboliza menor gasto de combustible y una ruta más rápida.</p>
                          </div>
                        </div>
                      </div>
                      <!-- End single service -->
                      <!-- Start single service -->
                      <div class="col-md-4">
                        <div class="mu-single-service">
                          <div class="mu-single-service-icon"><i class="fas fa-clipboard-check"></i></div>
                          <div class="mu-single-service-content">
                            <h3 style="font-size: 16px!important;">Revisa tus ventas y la cantidad de productos a llevar.</h3>
                            <p>Contamos con un módulo especializado en la revisión de pedidos, muy eficaz ya que además de mostrar el progreso de revisión, también informa la cantidad de cada producto a llevar en cada ruta.</p>
                          </div>
                        </div>
                      </div>
                      <!-- End single service -->
                    </div>
                  </div>
                </div>
              </div>
              <!-- End Service Content -->
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <!-- End Services -->

    <!-- Start Video -->
  
    <!-- End Video -->
 <center> <p style="color:#007bff!important"><a href="https://open.com.se/info/empresa.php" style="color:#007bff!important;font-size: 22px;">Mas información sobre plataforma OPEN para empresas <i class="fa fa-long-arrow-right"></i></p></a></center>
 
    <!-- Start Portfolio -->
    <section id="mu-portfolio">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-portfolio-area">
              <!-- Title -->
              <div class="row">
                <div class="col-md-12">
                  <div class="mu-title" style="    padding: 0 0%;">
                    <h2>Muestra de nuestra interfaz </h2>
                    <p>Adaptamos nuevas herramientas personalizadas para cada empresa gratuitamente. App para compras, web, plataforma de empresas, automatización de pedidos, logística y app para repartidores.</p>
                  </div>
                </div>
              </div>

              <div class="row">
                  <!-- Start Portfolio Filter -->
                  <div class="mu-portfolio-filter-area">
                    <ul class="mu-simplefilter">
                              <li class="active" data-filter="all">Todos<span>/</span></li>
                              <li data-filter="1">Diseño de tienda<span>/</span> </li>
                              <li data-filter="2">Diseño de panel de empresas<span>/</span></li>
                              <li data-filter="3">Estadisticas<span>/</span></li>
                              <li data-filter="4">Logistica<span>/</span> </li>
                              <li data-filter="5">App Repartidor <span>/</span> </li>
                              <li data-filter="6">App Pedidos</li>
                          </ul>
                  </div>

                  <!-- Start Portfolio Content -->
                  <div class="mu-portfolio-content">
                    <div class="filtr-container">
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
                                               <a class="mu-imglink" href="opentotal12.png" title="Tienda">
                                                    <img class="img-responsive" src="opentotal12.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Tienda</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
                                               <a class="mu-imglink" href="inter.png" title="Inicio empresa">
                                                    <img class="img-responsive" src="inter.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Inicio empresa</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
                                               <a class="mu-imglink" href="otra.png" title="Interfaz">
                                                    <img class="img-responsive" src="otra.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Interfaz</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
                                               <a class="mu-imglink" href="rutaefi.png" title="Inicio empresa">
                                                    <img class="img-responsive" src="rutaefi.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Rutas eficientes</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
                                               <a class="mu-imglink" href="carrito.png" title="Carrito">
                                                    <img class="img-responsive" src="carrito.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Carrito</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>

                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
                                 <a class="mu-imglink" href="compra.png" title="Compra">
                                    <img class="img-responsive" src="compra.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Compra</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                 </a>
                              </div>

                                            

                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="1">
                                               <a class="mu-imglink" href="listo.png" title="App compra">
                                                    <img class="img-responsive" src="listo.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">App compra</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                           
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
                                               <a class="mu-imglink" href="info.png" title="App compra">
                                                    <img class="img-responsive" src="info.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Informacion de compra</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            
                                             <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="5">
                                               <a class="mu-imglink" href="repartodor98.png" title="App Repartidor">
                                                    <img class="img-responsive" src="repartodor98.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">App Repartidor</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="5">
                                               <a class="mu-imglink" href="repartodor78bien.png" title="App Rertidor tablet">
                                                    <img class="img-responsive" src="repartodor78bien.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">App Rertidor tablet</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="5">
                                               <a class="mu-imglink" href="repartodor232654.png" title="Información pedido">
                                                    <img class="img-responsive" src="repartodor232654.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Información pedido</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="4">
                                               <a class="mu-imglink" href="entrega12.png" title="App compra">
                                                    <img class="img-responsive" src="entrega12.png" alt="image">
                                                    <div class="mu-filter-item-content">
                                                        <h4 class="mu-filter-item-title">Segimiento de pedidos</h4>
                                                        <span class="fa fa-long-arrow-right"></span>
                                                    </div>
                                               </a>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="2">
                                 <a class="mu-imglink" href="manejarpedi4378.png" title="Manejar pedidos">
                                    <img class="img-responsive" src="manejarpedi4378.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Manejar pedidos</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                </a>
                              </div>

                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                  <a class="mu-imglink" href="admin12.png" title="Estadisticas semanal monto">
                                    <img class="img-responsive" src="admin12.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Estadisticas semanal monto</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>

                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                  <a class="mu-imglink" href="estad.png" title="Estadistica mesual monto">
                                    <img class="img-responsive" src="estad.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Estadistica mesual monto</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>
                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                  <a class="mu-imglink" href="8OPEN3.jpg" title="Servicio al cliente">
                                    <img class="img-responsive" src="8OPEN3.jpg" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Servicio al cliente</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>
                              

                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                  <a class="mu-imglink" href="estad2.png" title="Estadistica semanal producto">
                                    <img class="img-responsive"  src="estad2.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Estadistica semanal producto</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>

                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                  <a class="mu-imglink" href="estad248.png" title="Estadistica mesual monto">
                                    <img class="img-responsive"  src="estad248.png" alt="image">
                                    <div class="mu-filter-item-content">
                                       <h4 class="mu-filter-item-title">Estadistica mesual monto</h4>
                                       <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>

                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                 <a class="mu-imglink" href="6767esta.png" title="Mensual comparación">
                                    <img class="img-responsive" src="6767esta.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Mensual comparación</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                </a>
                              </div>

                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                 <a class="mu-imglink" href="eatdi787.png" title="Comparación semanal productos">
                                    <img class="img-responsive" src="eatdi787.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Comparación semanal productos</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                 </a>
                              </div>

                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                  <a class="mu-imglink" href="semana.png" title="Productos ruta">
                                    <img class="img-responsive" src="semana.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Productos ruta</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>

                                <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="3">
                                  <a class="mu-imglink" href="rutbiencant.png" title="Estadistica ruta">
                                    <img class="img-responsive" src="rutbiencant.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Estadistica ruta</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>
                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="6">
                                  <a class="mu-imglink" href="pedido bien.png" title="Estadistica ruta">
                                    <img class="img-responsive" src="pedido bien.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Clientes a tomar pedido</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>
                              
                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="6">
                                  <a class="mu-imglink" href="pedido bien32.png" title="Estadistica ruta">
                                    <img class="img-responsive" src="pedido bien32.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Tomar pedido</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>
                              
                               <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="6">
                                  <a class="mu-imglink" href="tab1.png" title="Estadistica ruta">
                                    <img class="img-responsive" src="tab1.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Clientes a tomar pedido</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>
                              
                              <div class="col-xs-6 col-sm-6 col-md-4 filtr-item" data-category="6">
                                  <a class="mu-imglink" href="tab12.png" title="Estadistica ruta">
                                    <img class="img-responsive" src="tab12.png" alt="image">
                                    <div class="mu-filter-item-content">
                                      <h4 class="mu-filter-item-title">Tomar pedido</h4>
                                      <span class="fa fa-long-arrow-right"></span>
                                    </div>
                                  </a>
                              </div>
                              
                              

                          </div>
                  </div>
                  <!-- End Portfolio Content -->
                </div>
              
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Portfolio -->


    <!-- End Counter -->

    <!-- Start Pricing Table -->
    <section id="mu-pricing" style="padding: 25px 0px 0px 0px;">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-pricing-area">
              <!-- Title -->
              <div class="row">
                <div class="col-md-12">
                  <div class="mu-title" style="    padding: 0 0%;">
                    <h2>Nuestra tabla de precios</h2>
                    <div class="col-md-12">
                  <div class="mu-title" style="    padding: 0px;">
                        <button style="padding: 5px 15px;
    border: none;
    border: 1px solid;
    background-color: white;
    border-radius: 70px;"><a href="https://open.com.se/admin/registroempresa.php" class="mu-primary-btn mu-quote-btn">! Informales a tus clientes que pueden realizarte pedidos desde OPEN ¡</a></button> 
                
                  
                  </div>
                </div>
                    <p>Nuestros precios se ajustan a las distintas necesidades de nuestros clientes.</p>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="mu-pricing-content">
                    
                    
<div class="pricing-table">
    <div class="plan">
        <h3 class="plan__name">Mayorista</h3><as style="font-size:13px">Numero de pedidos mensual esta entre</as><span class="plan__price">75-200</span>
        <ul class="plan__features">
            <li>Las ventas menores de <strong>$25,000 </strong>de tus productos no tienen comision </liR>
            <li>Para ventas entre  <strong>$30,000 y $50,000 </strong>de tus productos  la comision es de <strong>$350</strong> por cada venta</li>
            <li>Para ventas mayores a <strong>$50,000 </strong>de tus productos  la comision es de <strong>$450 </strong>  por cada venta</li>
        </ul><strong>Oferta de lanzamiento:</strong><br><a class="signup" href="/admin/registroempresa.php">Registrate, los 2 primeros meses sin ninguna comisión. </a></div>
    <div class="plan selected" style="height: 643px!important;">
        <h3 class="plan__name">Empresa</h3><as style="font-size:13px">Numero de pedidos mensual es mayor a</as><span class="plan__price"><200</span>
        <ul class="plan__features">
            <li>Las ventas menores de <strong>$40,000 </strong>de tus productos  no tienen comision </li>
            <li>Para ventas entre <strong>$40,000 y $80,000 </strong>de tus productos la  comision es de <strong>$150</strong> por cada venta</li>
            <li>Para ventas mayores a <strong>$80,000 </strong> de tus productos  por cada venta la comision es de <strong>$300 </strong>por cada venta</li>
            <li>Nuevas herramientas particulares para cada empresa<strong> GRATIS</strong>  </li>
            <li>Precios especiales para<strong> GRANDES EMPRESAS</strong><br><strong>Contacto:</strong> servicioalcliente@open.com.se  </li>
        </ul><strong>Oferta de lanzamiento:</strong><br><a class="signup" href="/admin/registroempresa.php">Registrate, los 2 primeros meses sin ninguna comisión. </a></div>
    <div class="plan">
        <h3 class="plan__name">Mircroempresa</h3><as style="font-size:13px">Numero de pedidos mensual esta entre</as><span class="plan__price">0-75</span>
        <ul class="plan__features">
            <li>Las ventas menores de <strong>$17,500 </strong>de tus productos no tienen comision </li>
            <li>Para ventas entre  <strong>$30,000 y $50,000 </strong>de tus productos  la comision es de <strong>$450</strong> por cada venta</li>
            <li>Para ventas mayores a <strong>$50,000 </strong>de tus productos  la comision es de <strong>$500 </strong>  por cada venta</li>

        </ul><strong>Oferta de lanzamiento:</strong><br><a><a class="signup" href="/admin/registroempresa.php">Registrate, los 2 primeros meses sin ninguna comisión. </a></div>
</div>
<style type="text/css">
    @import 'https://fonts.googleapis.com/css?family=Droid+Sans:400,700';
 html {
     -webkit-box-sizing: border-box!important;
     -moz-box-sizing: border-box!important;
     box-sizing: border-box;
}
 *, *:before, *:after {
     box-sizing: inherit !important;
}
 body {
     font-family: 'Droid Sans', sans-serif !important;
     font-size: 100% !important;
     color: #232323 !important;
}

 @media (min-width: 600px) {
     .pricing-table {
         display: flex!important;
         justify-content: space-between!important;
    }
}
.pricing-table {
    width: 100%!important;
    max-width: 1010px!important;
    padding: 0px 0px!important;
    margin: -11px 5px 7px 40px;
}
.mu-portfolio-area {
    display: inline;
    float: left;
    padding: 0px 30px 0px 0px!important;
    width: 100%;
}
.mu-footer-bottom {
    background-color: #232729;
    display: inline;
    padding: 20px 0;
    float: left;
    width: 100%;
}
 .plan {
     background-image: linear-gradient(180deg, #f3f2f9 28%, #fff 28%)!important;
     border: 1px solid #c4c4c4!important;
     border-radius: 0.25em!important;
     box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.3)!important;
     padding: 12px 0px!important;
     margin: 20px 0!important;
     text-align: center!important;
}
 @media (min-width: 600px) {
     .plan {
         width: 32%!important;
            height: 603px!important;
    }
     .plan.selected {
         box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.5)!important;
         width: 34%!important;
         margin-top: -10px!important;
         margin-bottom: -10px!important;
    }
}
 .plan.selected {
     background-image: linear-gradient(180deg, #e3e1f1 28%, #fff 28%)!important;
}
 .plan__name {
     font-weight: 300!important;
}
 .plan__price {
     display: block!important;
     color: #7b7b7b!important;
     width: 80px!important;
     height: 80px!important;
     line-height: 80px !important;
     margin: 30px auto 60px !important;
     background-color: #fff !important;
     text-align: center !important;
     font-size: 1.5em !important;
     font-family: Georgia, serif !important;
     border-radius: 50% !important;
     box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.3) inset, 0px 0px 0px 10px #fff, 0px 0px 10px 11px rgba(0, 0, 0, 0.4) !important;
}
 .plan__features {
     margin: 0 0 30px 0 !important;

     padding: 0 !important;
     background-color: #fff !important;
     list-style-type: none!important;
}
 .plan__features li {
     padding: 10px 10px !important;
     border-top: 1px solid #c4c4c4 !important;
     font-size: 0.875em !important;
}
 .plan .signup {
     display: inline-block !important;
     padding: 10px 25px !important;
     text-decoration: none !important;
     color: #fff !important; 
     background-color: #05c314!important;
     border-radius: 3px !important;
     font-size: 12px !important;
     text-transform: uppercase !important;
}
 
</style>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Pricing Table -->

    <!-- End Client Testimonials -->

    <!-- Start from blog -->
    <section id="mu-from-blog">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-from-blog-area">
              <!-- Title -->
                
              <div class="row">
                <div class="col-md-12">
                  <div class="mu-title">
                    <h2>Servicios</h2>
                    <p>Le ofrecemos a tus clientes una plataforma que mejore su experiencia de compra mientras ayudamos tu administración de pedidos logistica.</p>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="mu-from-blog-content">
                    <div class="row">
                      <div class="col-md-4">
                        <article class="mu-blog-item">
                          <a href="#"><img src="interfaz782.png" alt="blgo image"></a>
                          <div class="mu-blog-item-content">
                            
                            <h2 class="mu-blog-item-title"><a href="#">Interfaz de control</a></h2>
                            <p>Controla y mejora tu logística, pedidos y seguimiento, además ten graficas importantes para conocer la demanda total y por cada producto.</p>
                              <!-- End from blog <a class="mu-blg-readmore-btn" href="blog-single.html">Read more <i class="fa fa-long-arrow-right"></i></a>--> 
                          </div>
                        </article>
                      </div>
                      <div class="col-md-4">
                        <article class="mu-blog-item">
                          <a href="#"><img src="repartodo.png" alt="blgo image"></a>
                          <div class="mu-blog-item-content">
                            
                            <h2 class="mu-blog-item-title"><a href="#">APP para repartidores</a></h2>
                            <p>Con esta app facilitaras la logística de entrega, teniendo a la mano la ruta de pedidos asignados y también información sobre los pedidos. </p>
                            <!--  <a class="mu-blg-readmore-btn" href="blog-single.html">Read more <i class="fa fa-long-arrow-right"></i></a>-->  
                          </div>
                        </article>
                      </div>
                      <div class="col-md-4">
                        <article class="mu-blog-item">
                          <a href="#"><img src="todo.png" alt="blgo image"></a>
                          <div class="mu-blog-item-content">

                            <h2 class="mu-blog-item-title"><a href="#">APP para personal de ventas</a></h2>
                            <p>Esta app esta diseña para facilitar el proceso de toma de pedidos dando la ruta de clientes, muy útil para administrar la logística. </p>
                            <!--  <a class="mu-blg-readmore-btn" href="blog-single.html">Read more <i class="fa fa-long-arrow-right"></i></a>-->
                          </div>
                        </article>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End from blog -->

  
    <!-- End Newsletter -->

    <!-- Start Clients -->

    <!-- End Clients -->

  </main>
  
  <!-- End main content --> 
      
      
  <!-- Start footer -->
  <footer id="mu-footer">
    <div class="mu-footer-top" style="background-color:#e2013b">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="mu-single-footer">
              <img class="mu-footer-logo" src="open.png" alt="logo">
              <p>Le ofrecemos a tus clientes una plataforma que mejore su experiencia de compra mientras ayudamos tu logistica. </p>
              
            </div>
          </div>
          <div class="col-md-3">
            <div class="mu-single-footer">
              <h3>Servicios</h3>
              <ul class="list-unstyled">
                  <li class="media">
                   <span><i class="fas fa-building"></i></span>
                    <div class="media-body">
                      <p><strong>Empresas: </strong>Plataforma de venta de productos, manejo de pedidos y estaditicas de ventas.</p>
                   
                    </div>
                  </li>
                  <li class="media">
                    <span><i class="fas fa-store"></i></span>
                    <div class="media-body">
                      <p><strong>Clientes: </strong>Plataforma para facilitar sus compras y su historial de pedidos.</p>
                    
                    </div>
                  </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3">
            <div class="mu-single-footer">
              <h3>Links</h3>
              
                <li><a href="https://open.com.se/?p=productos" style="color:white">Web de compras</a></li>
                                <li><a href="https://open.com.se/admin" style="color:white">Inicio de empresas</a></li>
                                <li><a href="https://open.com.se/admin/registroempresa.php"  style="color:white">Regitro</a></li>
                                <li><a href=" https://play.google.com/store/apps/details?id=com.wOPEN_10934662" style="color:white">APP</a></li>
                
              </ul>
            </div>
          </div>
          <div class="col-md-3">
            <div class="mu-single-footer">
              <h3>Informción de contacto</h3>
              <ul class="list-unstyled">
                <li class="media">
                  <span><i class="fas fa-envelope"></i></span>
                  <div class="media-body">
                    <p>servicioalcliente@open.com.se</p>
                  </div>
                </li>
                <li class="media">
                  <span class="fa fa-phone"></span>
                  <div class="media-body">
                     <p>Cel: 316-3779791</p>
                 
                  </div>
                </li>
              
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="mu-footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="mu-footer-bottom-area">
              <p class="mu-copy-right">&copy; Copyright <a rel="nofollow" href="http://markups.io">markups.io</a>. All right reserved.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

  </footer>
  <!-- End footer -->

  
  <!-- JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  <!-- Slick slider -->
    <script type="text/javascript" src="assets/js/slick.min.js"></script>
    <!-- Progress Bar -->
    <script src="https://unpkg.com/circlebars@1.0.3/dist/circle.js"></script>
    <!-- Filterable Gallery js -->
    <script type="text/javascript" src="assets/js/jquery.filterizr.min.js"></script>
    <!-- Gallery Lightbox -->
    <script type="text/javascript" src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Counter js -->
    <script type="text/javascript" src="assets/js/counter.js"></script>
    <!-- Ajax contact form  -->
    <script type="text/javascript" src="assets/js/app.js"></script>
    
  
    <!-- Custom js -->
  <script type="text/javascript" src="assets/js/custom.js"></script>

  <!-- About us Skills Circle progress  -->
  <script>
    // First circle
      new Circlebar({
        element : "#circle-1",
        type : "progress",
        maxValue:  "90"
      });
    
    // Second circle
      new Circlebar({
        element : "#circle-2",
        type : "progress",
        maxValue:  "84"
      });

      // Third circle
      new Circlebar({
        element : "#circle-3",
        type : "progress",
        maxValue:  "60"
      });

      // Fourth circle
      new Circlebar({
        element : "#circle-4",
        type : "progress",
        maxValue:  "74"
      });

  </script>
    
  </body>
</html>