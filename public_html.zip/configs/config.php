  
<?php
	@session_start();
	@extract($_REQUEST);
	$divisa = " $";
?>