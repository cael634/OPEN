<?php$conexion =mysqli_connect($host_mysql,$user_mysql,$pass_mysql,$db_mysql);
mysqli_select_db('compven',$conexion)