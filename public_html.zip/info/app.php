<!DOCTYPE html>
<html lang="en">
  <head>
    <style type="text/css">
        .mu-navbar {
    padding: 10px 0 !important;
}
#mu-hero {
    background-color: #e2013b!important;
    display: inline;
    float: left;
    width: 100%;
}
 .plan {
     background-image: linear-gradient(180deg, #f3f2f9 28%, #fff 28%)!important;
     border: 1px solid #c4c4c4!important;
     border-radius: 0.25em!important;
     box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.3)!important;
     padding: 12px 0px!important;
     margin: 20px 0!important;
     text-align: center!important;
}
.mu-single-slide-content p {
    margin-bottom: 0;
    font-size: 15px!important;
}
.mu-about-area {
    display: inline;
    float: left;
    padding: 50px 0px 0px 0px!important;
    width: 100%;
}
ul li {
    list-style: disc  !important;

    line-height: 1.59  !important;
}
.mu-footer-top {
    background-color: #e2013b!important;
    display: inline;
    float: left;
    padding: 55px 0;
    width: 100%;
}
ul li {
    list-style: none !important;
    
    /* line-height: 1.59; */
}
.scrollToTop, .mu-testimonial-slide .slick-dots li.slick-active, #mu-callto-action {
    background-color: #323435!important;
}
#mu-from-blog {
    background-color: #fff;
    float: left;
    padding: 0px 0px 100px 0px!important;
    display: inline;
    width: 100%;
}
#mu-call-to-action {
    background-image: url(prin.png)!important;
    float: left;
    position: relative;
    width: 100%;
}
.mu-title p {
    /* height: 300px; */
    width: auto;
}
element.style {
}
.mu-single-footer .list-unstyled li.media p {
    line-height: 1.5;
    margin-top: -2px!important;
    margin-bottom: 4px;
    font-size: 14px;
}
    </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>OPEN para empresas</title>
    <!-- Favicon -->
   <link rel="icon" type="image/png" href="open12498.png">
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Gallery Lightbox -->
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <!-- Skills Circle CSS  -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/circlebars@1.0.3/dist/circle.css">
    <script src="https://kit.fontawesome.com/98fd34a9f5.js" crossorigin="anonymous"></script>

    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    <!-- Fonts -->

    <!-- Google Fonts Raleway -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,400i,500,500i,600,700" rel="stylesheet">
    <!-- Google Fonts Open sans -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700,800" rel="stylesheet">
 
 
    </head>
  <body>

   <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>
    </a>
  <!-- END SCROLL TOP BUTTON -->
    
    <!-- Start Header -->
    <header id="mu-hero" style="height: 80px">
        <div class="container" style="height: 87px;">
            <nav class="navbar navbar-expand-lg navbar-light mu-navbar">
                <!-- Text based logo -->
                <a class="navbar-brand mu-logo" href="https://open.com.se/info/"><img src="open.png" style="width: 195px;"></a>
                <!-- image based logo -->
                <!-- <a class="navbar-brand mu-logo" href="index.html"><img src="assets/images/logo.png" alt="logo"></a> -->
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="fa fa-bars"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto mu-navbar-nav">
                  <li class="nav-item active">
                    <a href="index.php" style="color:#000000bf">Home</a>
                  </li>
                  <li class="nav-item"><a href="/admin/index.php">Iniciar sesion</a></li>
                  <li class="nav-item"><a href="/admin/registroempresa.php">Registro</a></li>

             
                
                </ul>
              </div>
            </nav>
        </div>
    </header>
    <!-- End Header -->

   
  <div id="mu-call-to-action">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mu-call-to-action-area">
                            <div class="mu-call-to-action-left">
                                <h2>Comienza a tomar pedidos de tus clientes <br> desde Open</h2>
                                <p>Tu catalogo disponible las 24 hora a tus clientes</p>
                                <br>
                <p style="    font-size: 22px;">Fecha de lanzamiento 22 de junio.</p>
                            </div>
                            
                            <a href="https://open.com.se/admin/registroempresa.php" class="mu-primary-btn mu-quote-btn">Comenzar 2 meses sin ningun costo <i class="fa fa-long-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    <!-- Start main content -->
    <main>
        <!-- Start About -->
        <section id="mu-about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mu-about-area">
                            <!-- Title -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mu-title" style="padding: 0 0%;">
                                        <h2>Chat, monto minimo y clientes particulares</h2>
                                      
                                    </div>
                                </div>
                            </div>
                            <!-- Start Feature Content -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mu-about-left">
                                        <img class="" src="chat545.png" alt="img">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mu-about-right">
                                        <ul>
                                            <li>
                                                <h3>Chat </h3>
                                                <p>Los clientes podrán comunicar de forma efectiva sus preguntas, quejas y sugerencias. De esta forma estaras mas cerca de tus clientes.</p>
                                            </li>
                                            <li>
                                                <h3>Monto minimo para realizar compra</h3>
                                                <p>La empresa tiene la opción de fijar un monto mínimo para poder realizarle pedidos, evitando así pedidos muy bajo valor que no son muy eficientes realizar.</p>
                                            </li>
                                           <li>
                                                <h3>Ventas a clientes particulares</h3>
                                                <p>Hay la opción habilitar ventas a clientes particulares estableciéndoles un monto mínimo, así podrá expandir su canal de pedidos al cliente final que realizara un pedido de gran consumo. </p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- End Feature Content -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End About -->
        <!-- Start About -->
        <section id="mu-about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mu-about-area">
                            <!-- Title -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mu-title">
                                        <h2>Ausencia y pedidos proximos</h2>
                                      
                                    </div>
                                </div>
                            </div>
                            <!-- Start Feature Content -->
                            <div class="row">
                                
                                <div class="col-md-6">
                                    <div class="mu-about-right">
                                        <ul>
                                            <li>
                                                <h3>Ausencia</h3>
                                                <p>Si la empresa desea puede habilitar la opción de que sus clientes por medio de la plataforma de OPEN comprador puedan informar que estarán ausentes en un intervalo de tiempo o todo el día, como beneficio el repartidor ahorra tiempo de espera y el comprador dependiendo de la antelación que suministre la información, se podrá asignarle otro día de entrega cercano.</p>
                                            </li>
                                            <li>
                                                <h3>Pedidos proximos</h3>
                                                <p>*(El cambio de estado del pedido puede ser realizado por la empresa o si desea lo puede hacer el mismo comprador, para facilidad de la empresa si maneja la plataforma con solo la finalidad de tomar pedidos) Para procesos eficientes  tanto del comprador como del repartidor, si la empresa desea puede habilitar esta función que puede ser usada tanto desde el panel de control o desde la App OPEN repartidor, su función es informar al cliente que su pedido está cerca, así podra alistarse para recibir el pedido y reducir el tiempo de entrega. </p>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mu-about-left">
                                        <img class="" src="ausen.jpg" alt="img">
                                    </div>
                                </div>
                            </div>
                            <!-- End Feature Content -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

                <!-- Start About -->
        <section id="mu-about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mu-about-area">
                            <!-- Title -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mu-title">
                                        <h2>Devolución y pedidos</h2>
                                  
                                    </div>
                                </div>
                            </div>
                            <!-- Start Feature Content -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mu-about-left">
                                        <img class="" src="devolucion14.png" alt="img">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mu-about-right">
                                        <ul>
                                            <li>
                                                <h3>Devolución</h3>
                                                <p>La empresa tiene puede dar la opción a sus clientes de pedir la devolución de productos ya sea por vencimiento y/o porque estos hayan sido entregados en mal estado. Logrando eficiencia a la hora de entrega de pedidos y no falte productos para hacer el correspondiente proceso. </p>
                                            </li>
                                            <li>
                                                <h3>Pedidos</h3>
                                                <p>Tus clientes cuentan con una plataforma interactiva para realizar sus pedidos, conocer el día o tiempo de entrega y tener un historial e información de estos muy eficaz a la hora de evaluar gastos.</p>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- End Feature Content -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to Action -->
      
        
        <!-- Start Services -->
  
        <!-- Start Pricing Table -->
      
                            <!-- Title -->
                         
<style type="text/css">
    @import 'https://fonts.googleapis.com/css?family=Droid+Sans:400,700';
 html {
     -webkit-box-sizing: border-box!important;
     -moz-box-sizing: border-box!important;
     box-sizing: border-box;
}
 *, *:before, *:after {
     box-sizing: inherit !important;
}
 body {
     font-family: 'Droid Sans', sans-serif !important;
     font-size: 100% !important;
     color: #232323 !important;
}

 @media (min-width: 600px) {
     .pricing-table {
         display: flex!important;
         justify-content: space-between!important;
    }
}
.pricing-table {
    width: 100%!important;
    max-width: 1010px!important;
    padding: 0px 0px!important;
    margin: -11px 5px 7px 40px;
}
.mu-portfolio-area {
    display: inline;
    float: left;
    padding: 0px 30px 0px 0px!important;
    width: 100%;
}
.mu-footer-bottom {
    background-color: #232729;
    display: inline;
    padding: 20px 0;
    float: left;
    width: 100%;
}
 .plan {
     background-image: linear-gradient(180deg, #f3f2f9 28%, #fff 28%)!important;
     border: 1px solid #c4c4c4!important;
     border-radius: 0.25em!important;
     box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.3)!important;
     padding: 12px 0px!important;
     margin: 20px 0!important;
     text-align: center!important;
}
 @media (min-width: 600px) {
     .plan {
         width: 32%!important;
             height: 570px!important;
    }
     .plan.selected {
         box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.5)!important;
         width: 34%!important;
         margin-top: -10px!important;
         margin-bottom: -10px!important;
    }
}
 .plan.selected {
     background-image: linear-gradient(180deg, #e3e1f1 28%, #fff 28%)!important;
}
 .plan__name {
     font-weight: 300!important;
}
 .plan__price {
     display: block!important;
     color: #7b7b7b!important;
     width: 80px!important;
     height: 80px!important;
     line-height: 80px !important;
     margin: 30px auto 60px !important;
     background-color: #fff !important;
     text-align: center !important;
     font-size: 1.5em !important;
     font-family: Georgia, serif !important;
     border-radius: 50% !important;
     box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.3) inset, 0px 0px 0px 10px #fff, 0px 0px 10px 11px rgba(0, 0, 0, 0.4) !important;
}
 .plan__features {
     margin: 0 0 30px 0 !important;

     padding: 0 !important;
     background-color: #fff !important;
     list-style-type: none!important;
}
 .plan__features li {
     padding: 10px 10px !important;
     border-top: 1px solid #c4c4c4 !important;
     font-size: 0.875em !important;
}
 .plan .signup {
     display: inline-block !important;
     padding: 10px 25px !important;
     text-decoration: none !important;
     color: #fff !important; 
     background-color: #05c314!important;
     border-radius: 3px !important;
     font-size: 12px !important;
     text-transform: uppercase !important;
}
 
</style>
                                
        <!-- End Pricing Table -->

        <!-- End Client Testimonials -->

        <!-- Start from blog -->
      
        <!-- End from blog -->

    
        <!-- End Newsletter -->

        <!-- Start Clients -->

        <!-- End Clients -->

    </main>
    
    <!-- End main content -->   
            
            
    <!-- Start footer -->
    <footer id="mu-footer">
        <div class="mu-footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mu-single-footer">
                            <img class="mu-footer-logo" src="open.png" alt="logo">
                            <p>Le ofrecemos a tus clientes una plataforma que mejore su experiencia de compra mientras ayudamos tu logistica. </p>
                            
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mu-single-footer">
                            <h3>Servicios</h3>
                            <ul class="list-unstyled">
                                <li class="media">
                                   <span><i class="fas fa-building"></i></span>
                                    <div class="media-body">
                                        <p><strong>Empresas: </strong>Plataforma de venta de productos, manejo de pedidos y estaditicas de ventas.</p>
                                   
                                    </div>
                                </li>
                                <li class="media">
                                    <span><i class="fas fa-store"></i></span>
                                    <div class="media-body">
                                        <p><strong>Clientes: </strong>Plataforma para facilitar sus compras y su historial de pedidos.</p>
                                    
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mu-single-footer">
                            <h3>Links</h3>
                            
                                <li>open.com.se</li>
                                <li>Inicio de empresas</li>
                                <li>Regitro</li>
                                <li>APP</li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mu-single-footer">
                            <h3>Informción de contacto</h3>
                            <ul class="list-unstyled">
                              <li class="media">
                                <span><i class="fas fa-envelope"></i></span>
                                <div class="media-body">
                                    <p>servicioalcliente@open.com.se</p>
                                </div>
                              </li>
                              <li class="media">
                                <span class="fa fa-phone"></span>
                                <div class="media-body">
                                   <p>Cel: 316-3779791</p>
                               
                                </div>
                              </li>
                            
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mu-footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mu-footer-bottom-area">
                            <p class="mu-copy-right">&copy; Copyright <a rel="nofollow" href="http://markups.io">markups.io</a>. All right reserved.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- End footer -->

    
    <!-- JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <!-- Slick slider -->
    <script type="text/javascript" src="assets/js/slick.min.js"></script>
    <!-- Progress Bar -->
    <script src="https://unpkg.com/circlebars@1.0.3/dist/circle.js"></script>
    <!-- Filterable Gallery js -->
    <script type="text/javascript" src="assets/js/jquery.filterizr.min.js"></script>
    <!-- Gallery Lightbox -->
    <script type="text/javascript" src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Counter js -->
    <script type="text/javascript" src="assets/js/counter.js"></script>
    <!-- Ajax contact form  -->
    <script type="text/javascript" src="assets/js/app.js"></script>
    
    
    <!-- Custom js -->
    <script type="text/javascript" src="assets/js/custom.js"></script>

    <!-- About us Skills Circle progress  -->
    <script>
        // First circle
        new Circlebar({
        element : "#circle-1",
        type : "progress",
          maxValue:  "90"
        });
        
        // Second circle
        new Circlebar({
        element : "#circle-2",
        type : "progress",
          maxValue:  "84"
        });

        // Third circle
        new Circlebar({
        element : "#circle-3",
        type : "progress",
          maxValue:  "60"
        });

        // Fourth circle
        new Circlebar({
        element : "#circle-4",
        type : "progress",
          maxValue:  "74"
        });

    </script>
    
  </body>
</html>