<?php

$servername = "localhost";
$user_mysql = "u114005028_open";
$username = "u114005028_open";
$password = "632003a632003a";
$link= mysqli_connect('localhost','u114005028_open','>c55CDcl','u114005028_open');

    if($link === false){
        die("ERROR EN LA CONEXION" . mysqli_connect_error());
    }
?>
<?php

