<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Select dependientes o combos dinámicos con php, mysql y jQuery</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <link href="style.css" rel="stylesheet">
  <script src="functions.js"></script>
</head>
<body>

<h1>Ejemplo de Select Dependientes o Combos Dinámicos</h1>

<div>
<h2>Continentes</h2>
<select name="continentes" id="continentes">
  <option value="0">Seleccione</option>
</select>
</div>

<div>
<h2>Países</h2>
<select name="paises" id="paises">
  <option value="0">Seleccione</option>
</select>
</div>

</body>
</html>