jQuery('#css-demo').slippry({
  slippryWrapper: '<div class="sy-box css-demo" />', 
  adaptiveHeight: true, 
  useCSS: true, 
  autoHover: false,
  transition: 'horizontal'
});